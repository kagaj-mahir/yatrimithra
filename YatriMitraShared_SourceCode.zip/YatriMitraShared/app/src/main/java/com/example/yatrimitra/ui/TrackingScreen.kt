package com.example.yatrimitra.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.yatrimitra.model.SimulationState
import com.example.yatrimitra.model.Stop
import com.example.yatrimitra.viewmodel.TrackingViewModel

// ── Colours ──────────────────────────────────────────────────────────────────
private val Navy     = Color(0xFF0A2342)
private val Teal     = Color(0xFF028090)
private val Mint     = Color(0xFF02C39A)
private val Seafoam  = Color(0xFF00A896)
private val DarkCard = Color(0xFF13324F)
private val Warn     = Color(0xFFE8573B)

// ── Screen ────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackingScreen(
    viewModel: TrackingViewModel,
    onNavigateBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Live Tracker", color = Color.White, fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
            )
        },
        containerColor = Navy
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            item { RouteProgressCard(state) }
            item { EtaCard(state) }
            item {
                Text(
                    "Select Your Stop",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
            items(state.stops) { stop ->
                StopItem(
                    stop      = stop,
                    isSelected = stop.id == state.selectedStopId,
                    isPassed  = stop.distanceFromStart <= state.currentDistanceKm,
                    onClick   = { viewModel.selectStop(stop.id) }
                )
            }
            item { ControlButtons(state, viewModel) }
        }
    }
}

// ── Route progress card ───────────────────────────────────────────────────────
@Composable
fun RouteProgressCard(state: SimulationState) {
    val totalKm   = state.stops.lastOrNull()?.distanceFromStart ?: 1f
    val progress  = (state.currentDistanceKm / totalKm).coerceIn(0f, 1f)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.DirectionsBus, contentDescription = null, tint = Mint, modifier = Modifier.size(22.dp))
                Text("Vehicle Position", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                StatusBadge(state)
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(50)),
                color            = Mint,
                trackColor       = Color(0xFF1E4060),
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("%.2f km".format(state.currentDistanceKm), color = Mint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("%.1f km total".format(totalKm), color = Color(0xFF8BAFC4), fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun StatusBadge(state: SimulationState) {
    val (text, color) = when {
        state.hasArrived -> "Arrived" to Mint
        state.isRunning  -> "Moving"  to Warn
        else             -> "Stopped" to Color(0xFF8BAFC4)
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

// ── ETA card ─────────────────────────────────────────────────────────────────
@Composable
fun EtaCard(state: SimulationState) {
    val selectedStop = state.stops.find { it.id == state.selectedStopId }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("ETA to Selected Stop", color = Color(0xFF8BAFC4), fontSize = 13.sp)

            when {
                selectedStop == null -> {
                    Text("— Select a stop below —", color = Teal, fontSize = 18.sp)
                }
                state.etaSeconds == null -> {
                    Text("✓ Passed / Arrived", color = Mint, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                else -> {
                    val mins = state.etaSeconds / 60
                    val secs = state.etaSeconds % 60
                    Text(
                        text = "%02d:%02d".format(mins, secs),
                        color = Mint,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text("min : sec", color = Color(0xFF8BAFC4), fontSize = 12.sp)
                }
            }

            selectedStop?.let {
                Text(
                    text = "▶  ${it.name}",
                    color = Seafoam,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// ── Stop list item ────────────────────────────────────────────────────────────
@Composable
fun StopItem(
    stop: Stop,
    isSelected: Boolean,
    isPassed: Boolean,
    onClick: () -> Unit
) {
    val bgColor     = when { isSelected -> Teal.copy(alpha = 0.22f); isPassed -> Color(0xFF0D1F2D); else -> DarkCard }
    val borderColor = when { isSelected -> Teal; else -> Color.Transparent }
    val textColor   = when { isPassed -> Color(0xFF4A7A90); else -> Color.White }
    val dotColor    = when { isPassed -> Mint; isSelected -> Teal; else -> Color(0xFF4A7A90) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Dot
        Box(
            modifier = Modifier
                .size(14.dp)
                .clip(CircleShape)
                .background(dotColor)
        )

        Column(modifier = Modifier.weight(1f)) {
            Text(stop.name, color = textColor, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            Text("%.1f km from start".format(stop.distanceFromStart), color = Color(0xFF5A8FA8), fontSize = 12.sp)
        }

        Icon(
            Icons.Filled.LocationOn,
            contentDescription = null,
            tint = if (isSelected) Teal else Color(0xFF2A4F6A),
            modifier = Modifier.size(20.dp)
        )
    }
}

// ── Control buttons ───────────────────────────────────────────────────────────
@Composable
fun ControlButtons(state: SimulationState, viewModel: TrackingViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Start / Stop
        Button(
            onClick  = { if (state.isRunning) viewModel.stopSimulation() else viewModel.startSimulation() },
            modifier = Modifier
                .weight(1f)
                .height(50.dp),
            shape    = RoundedCornerShape(12.dp),
            colors   = ButtonDefaults.buttonColors(
                containerColor = if (state.isRunning) Warn else Mint
            )
        ) {
            Text(
                text       = if (state.isRunning) "Stop" else "Start",
                color      = Navy,
                fontWeight = FontWeight.Bold,
                fontSize   = 15.sp
            )
        }

        // Reset
        OutlinedButton(
            onClick  = { viewModel.resetSimulation() },
            modifier = Modifier
                .weight(1f)
                .height(50.dp),
            shape    = RoundedCornerShape(12.dp),
            border   = ButtonDefaults.outlinedButtonBorder.copy(width = 1.5.dp),
            colors   = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF8BAFC4))
        ) {
            Text("Reset", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}
