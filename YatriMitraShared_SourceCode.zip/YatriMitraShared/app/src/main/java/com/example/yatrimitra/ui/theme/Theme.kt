package com.example.yatrimitra.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary          = Color(0xFF02C39A),
    onPrimary        = Color(0xFF0A2342),
    secondary        = Color(0xFF028090),
    onSecondary      = Color.White,
    background       = Color(0xFF0A2342),
    surface          = Color(0xFF13324F),
    onSurface        = Color.White,
    onBackground     = Color.White,
)

@Composable
fun YatriMitraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        content     = content
    )
}
