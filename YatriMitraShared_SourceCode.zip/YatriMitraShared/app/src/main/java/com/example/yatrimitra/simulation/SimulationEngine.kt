package com.example.yatrimitra.simulation

import com.example.yatrimitra.model.RouteData
import com.example.yatrimitra.model.SimulationState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * SimulationEngine moves the vehicle along the route tick-by-tick
 * and exposes live SimulationState via StateFlow.
 *
 * Tick interval : 1 second  (represents real time)
 * Distance/tick : speed(km/h) / 3600  → km per second
 */
class SimulationEngine(private val scope: CoroutineScope) {

    private val vehicle = RouteData.vehicle
    private val stops   = RouteData.stops

    private val _state = MutableStateFlow(
        SimulationState(
            vehicle          = vehicle,
            stops            = stops,
            currentDistanceKm = 0f,
            selectedStopId   = null,
            etaSeconds       = null,
            isRunning        = false,
            hasArrived       = false
        )
    )
    val state: StateFlow<SimulationState> = _state.asStateFlow()

    private var simulationJob: Job? = null

    // Distance the vehicle covers each tick (1 second)
    private val distancePerTickKm: Float = vehicle.speedKmh / 3600f

    // ─── Public API ────────────────────────────────────────────────────────────

    fun start() {
        if (simulationJob?.isActive == true) return
        simulationJob = scope.launch {
            _state.value = _state.value.copy(isRunning = true, hasArrived = false)
            while (_state.value.currentDistanceKm < RouteData.totalDistanceKm) {
                delay(1_000L)
                val newDist = (_state.value.currentDistanceKm + distancePerTickKm)
                    .coerceAtMost(RouteData.totalDistanceKm)
                _state.value = _state.value.copy(
                    currentDistanceKm = newDist,
                    etaSeconds        = calculateEta(newDist, _state.value.selectedStopId)
                )
            }
            // Reached end of route
            _state.value = _state.value.copy(isRunning = false, hasArrived = true)
        }
    }

    fun stop() {
        simulationJob?.cancel()
        _state.value = _state.value.copy(isRunning = false)
    }

    fun reset() {
        simulationJob?.cancel()
        _state.value = SimulationState(
            vehicle           = vehicle,
            stops             = stops,
            currentDistanceKm = 0f,
            selectedStopId    = null,
            etaSeconds        = null,
            isRunning         = false,
            hasArrived        = false
        )
    }

    fun selectStop(stopId: Int) {
        _state.value = _state.value.copy(
            selectedStopId = stopId,
            etaSeconds     = calculateEta(_state.value.currentDistanceKm, stopId)
        )
    }

    // ─── Private helpers ───────────────────────────────────────────────────────

    /**
     * ETA = remaining distance / speed
     * Returns null if the vehicle has already passed the selected stop.
     */
    private fun calculateEta(currentDist: Float, stopId: Int?): Int? {
        val stop = stops.find { it.id == stopId } ?: return null
        val remaining = stop.distanceFromStart - currentDist
        if (remaining <= 0f) return null                      // already passed
        val etaHours   = remaining / vehicle.speedKmh
        val etaSeconds = (etaHours * 3600f).toInt()
        return etaSeconds
    }
}
