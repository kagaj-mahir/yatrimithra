package com.example.yatrimitra.model

/**
 * Represents a single stop on the route.
 */
data class Stop(
    val id: Int,
    val name: String,
    val distanceFromStart: Float   // in kilometres from the route origin
)

/**
 * Represents the shared vehicle travelling along the route.
 */
data class Vehicle(
    val id: Int = 1,
    val name: String = "Auto 01",
    val speedKmh: Float = 30f      // average speed in km/h
)

/**
 * Live snapshot of the simulation state sent to the UI.
 */
data class SimulationState(
    val vehicle: Vehicle,
    val stops: List<Stop>,
    val currentDistanceKm: Float,   // how far the vehicle has travelled from start
    val selectedStopId: Int?,
    val etaSeconds: Int?,           // null when vehicle has passed the stop
    val isRunning: Boolean,
    val hasArrived: Boolean
)
