package com.example.yatrimitra.model

/**
 * Static route definition.
 * All distances are from the route origin (Stop 0) in kilometres.
 */
object RouteData {

    val vehicle = Vehicle(id = 1, name = "Auto 01", speedKmh = 30f)

    val stops = listOf(
        Stop(id = 0, name = "Bus Stand (Origin)",      distanceFromStart = 0.0f),
        Stop(id = 1, name = "Market Circle",           distanceFromStart = 1.5f),
        Stop(id = 2, name = "Govt. School",            distanceFromStart = 3.0f),
        Stop(id = 3, name = "Panchayat Office",        distanceFromStart = 4.8f),
        Stop(id = 4, name = "Primary Health Centre",   distanceFromStart = 6.2f),
        Stop(id = 5, name = "Grameen Bank",            distanceFromStart = 7.5f),
        Stop(id = 6, name = "End Point",               distanceFromStart = 9.0f)
    )

    /** Total route length in km */
    val totalDistanceKm: Float = stops.last().distanceFromStart
}
