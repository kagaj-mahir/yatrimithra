package com.example.yatrimitra.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.yatrimitra.model.SimulationState
import com.example.yatrimitra.simulation.SimulationEngine
import kotlinx.coroutines.flow.StateFlow

class TrackingViewModel : ViewModel() {

    private val engine = SimulationEngine(viewModelScope)

    /** Expose live state to the UI */
    val state: StateFlow<SimulationState> = engine.state

    fun startSimulation()   = engine.start()
    fun stopSimulation()    = engine.stop()
    fun resetSimulation()   = engine.reset()
    fun selectStop(id: Int) = engine.selectStop(id)

    override fun onCleared() {
        super.onCleared()
        engine.stop()
    }
}
