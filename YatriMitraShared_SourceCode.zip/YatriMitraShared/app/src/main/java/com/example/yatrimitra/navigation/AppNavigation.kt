package com.example.yatrimitra.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.yatrimitra.ui.HomeScreen
import com.example.yatrimitra.ui.TrackingScreen
import com.example.yatrimitra.viewmodel.TrackingViewModel

sealed class Screen(val route: String) {
    object Home     : Screen("home")
    object Tracking : Screen("tracking")
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val viewModel: TrackingViewModel = viewModel()

    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(onNavigateToTracking = {
                navController.navigate(Screen.Tracking.route)
            })
        }
        composable(Screen.Tracking.route) {
            TrackingScreen(
                viewModel  = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
