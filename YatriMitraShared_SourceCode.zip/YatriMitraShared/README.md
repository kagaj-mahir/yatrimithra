# Yatri-Mitra Shared 🚌
### Smart Mobility Tracker for Rural Transportation

---

## Project Overview
Yatri-Mitra Shared is an Android application that simulates shared auto/vehicle tracking
and provides real-time ETA (Estimated Time of Arrival) for commuters in rural and
semi-urban areas — without requiring GPS infrastructure.

---

## Architecture
```
MainActivity
    └── AppNavigation (NavHost)
            ├── HomeScreen
            └── TrackingScreen
                    └── TrackingViewModel (StateFlow)
                                └── SimulationEngine (Coroutines)
                                            └── RouteData (Stops & Vehicle)
```

---

## Tech Stack
| Layer        | Technology                    |
|--------------|-------------------------------|
| Language     | Kotlin                        |
| UI           | Jetpack Compose + Material 3  |
| State        | StateFlow                     |
| Background   | Kotlin Coroutines             |
| Navigation   | Navigation Compose            |
| Build        | Gradle 8.2, AGP 8.2.1        |
| Min SDK      | 24 (Android 7.0)              |
| Target SDK   | 34 (Android 14)               |

---

## ETA Formula
```
ETA (seconds) = (Stop Distance - Vehicle Distance) / Speed (km/h) × 3600
```

---

## File Structure
```
YatriMitraShared/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/yatrimitra/
│       │   ├── MainActivity.kt
│       │   ├── model/
│       │   │   ├── Models.kt          ← Stop, Vehicle, SimulationState
│       │   │   └── RouteData.kt       ← 7-stop predefined route
│       │   ├── simulation/
│       │   │   └── SimulationEngine.kt ← Coroutine-based tick engine
│       │   ├── viewmodel/
│       │   │   └── TrackingViewModel.kt
│       │   ├── navigation/
│       │   │   └── AppNavigation.kt
│       │   └── ui/
│       │       ├── HomeScreen.kt
│       │       ├── TrackingScreen.kt
│       │       └── theme/
│       │           └── Theme.kt
│       └── res/values/themes.xml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── gradle/wrapper/gradle-wrapper.properties
```

---

## How to Run
1. Open **Android Studio** (Hedgehog or newer)
2. Select **Open an Existing Project** → choose the `YatriMitraShared` folder
3. Wait for Gradle sync to complete
4. Run on an emulator or physical device (API 24+)

---

## Author
**Manoj Kumar K**
Android App Development Intern — MindMatrix.io
B.E. Electronics & Communication Engineering, AIEMS (VTU) 2026
